package exercises.part3;

import java.time.Instant;
import java.time.Year;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise02_Objects 
{
	public static void main(String[] args) 
	{
		System.out.println("OldStyle_Bad(null)");
		System.out.println(provideDefault_OldStyle_Bad(null));
		System.out.println("OldStyle_Bad((Mike)");
		System.out.println(provideDefault_OldStyle_Bad(List.of("Mike")));
		System.out.println("NewStyle(null)");
		System.out.println(provideDefault_NewStyle(null));
		System.out.println("NewStyle()");
		System.out.println(provideDefault_NewStyle(List.of("Mike")));
	}
	
	public static List<String> provideDefault_NewStyle(final List<String> names) 
	{
		final List<String> namesWithFallback = /* TODO */ null;
			
		return namesWithFallback;
	}

	public static List<String> provideDefault_OldStyle(final List<String> names) 
	{
		List<String> namesWithFallback = names;
		if (namesWithFallback == null)
		{
			namesWithFallback = longRunningCalcOfNames();
		}
			
		return namesWithFallback;
	}

	public static List<String> provideDefault_OldStyle_Bad(final List<String> names) 
	{
		List<String> namesWithFallback = longRunningCalcOfNames();
		if (names != null)
		{
			namesWithFallback = names;
		}
			
		return namesWithFallback;
	}
	
	private static List<String> longRunningCalcOfNames() 
	{
		try {
			TimeUnit.SECONDS.sleep(4);
		} catch (InterruptedException e) {
			
		}
		
		return List.of("Tim", "Tom", "Mike", "Andy");
	}
}
