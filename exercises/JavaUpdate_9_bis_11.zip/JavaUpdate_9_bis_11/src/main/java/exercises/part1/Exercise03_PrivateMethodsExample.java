package exercises.part1;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public interface Exercise03_PrivateMethodsExample 
{
	public abstract int method();

	public default void calc1(float a, float b) 
	{
		float avg = (a + b) / 2;
		System.out.println("sum: " + (a + b) + " / avg: " + avg);
	}

	public default void calc2(int a, int b) 
	{
		int sum = a + b;
		float avg = (float) sum / 2;
		System.out.println("sum: " + sum + " / avg: " + avg);
	}
}