package exercises.part1;

import static java.util.stream.Collectors.filtering;
import static java.util.stream.Collectors.flatMapping;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toSet;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise10_Collectors 
{
	public static void main(final String[] args) 
	{
		 exercise10a();
		 exercise10b();
		 exercise10c();
		 exercise10d();
		 exercise10e();
	}
	
	public static void exercise10a()
	{
		final Stream<String> names = Stream.of("Tim", "Tom", "Michael", "Thomas", "Karthikeyan", "Marius");
		final Predicate<String> moreThen5Chars = null; // TODO
		
		final Set<String> longNames = Set.of("TODO");
		System.out.println(longNames);
	}
		
	public static void exercise10b()
	{
		final Stream<String> names = Stream.of("Tim", "Tom", "Michael", "Thomas", "Karthikeyan", "Marius");
		final Predicate<String> moreThen5Chars = null; // TODO
		final Function<String, Character> firstChar = null; // TODO

		final Map<Character, Set<String>> groupedLongNames = Map.of('T', Set.of("TODO"));
		System.out.println(groupedLongNames);
	}
	
	public static void exercise10c()
	{
		final Map<String, Long> personAgeMapping = Map.of("Tim", 47L, "Tom", 12L, "Michael", 47L, "Max", 25L);

		final Function<Map.Entry<String, Long>, Character> firstChar = entry -> entry.getKey().charAt(0);
		final Predicate<Map.Entry<String, Long>> isAdult = entry -> entry.getValue()  >= 18;

		final Map<Character, Set<Entry<String, Long>>> filteredPersons = personAgeMapping.entrySet().stream().
				        collect(groupingBy(firstChar, filtering(isAdult, toSet())));
		System.out.println(filteredPersons);
	}

	public static void exercise10d()
	{
		final Map<String, Long> personAgeMapping = Map.of("Tim", 47L, "Tom", 12L, "Michael", 47L, "Max", 25L);
				
		final Function<Map.Entry<String, Long>, Character> firstChar = entry -> entry.getKey().charAt(0);
		final Predicate<Map.Entry<String, Long>> isAdult = entry -> entry.getValue()  >= 18;

		final Map<Character, Set<String>> filteredPersons = personAgeMapping.entrySet().stream().
				        collect(groupingBy(firstChar, filtering(isAdult, mapping(entry -> entry.getKey(), toSet()))));
		System.out.println(filteredPersons);
	}
	
	public static void exercise10e()
	{
		final Stream<Set<String>> characters = Stream.of(Set.of("a", "c", "e"), 
				                                         Set.of("a", "b"), 
				                                         Set.of("a", "b", "c", "d"),
				                                         Set.of("a", "b", "c", "d", "f")
				                                        );
				
		final Set<String> simpleCharaters = characters.collect(flatMapping((Set<String> value) -> value.stream(), toSet()));
		System.out.println(simpleCharaters);
	}
}
