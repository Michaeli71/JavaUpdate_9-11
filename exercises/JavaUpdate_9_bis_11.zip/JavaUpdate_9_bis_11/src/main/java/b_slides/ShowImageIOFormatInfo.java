package b_slides;

import java.util.Arrays;

import javax.imageio.ImageIO;

/**
 * Beispielprogramm für das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017 by Michael Inden 
 */
public class ShowImageIOFormatInfo
{
    static public void main(final String args[]) throws Exception
    {
        System.out.println("Reader: ");
        final String[] readFormats = ImageIO.getReaderFormatNames();
        Arrays.stream(readFormats).forEach(name -> System.out.println(name));
        
        System.out.println("Writers: ");
        final String[] writeFormats = ImageIO.getWriterFormatNames();
        Arrays.stream(writeFormats).forEach(name -> System.out.println(name));
    }
}