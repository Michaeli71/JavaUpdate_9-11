package solutions.part1;

import java.lang.ProcessHandle.Info;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise02_ProcessHandleExample 
{
    public static void main(String[] args)
    {
    	// 2 a
        final Info info = ProcessHandle.current().info();
        
        System.out.println("Start time: " + info.startInstant());
        System.out.println("Total cpu: " + info.totalCpuDuration());
        System.out.println("Complete info: " + info);
        
        // 2 b
        final long currentProcessCount = ProcessHandle.allProcesses().count();
        System.out.println("#processes: " + currentProcessCount);
        
        // 2 c
        final Predicate<? super Info> isJavaProcess = procInfo -> 
        {
        	final Optional<String> optcommand = procInfo.command();
        	if (optcommand.isPresent())
        	{
        		return optcommand.get().contains("java");
        	}
        	return false;
        };
        System.out.println("Java processes:"); 
		ProcessHandle.allProcesses().
		              map(proc -> proc.info()).
		              filter(isJavaProcess).
		              forEach(System.out::println);
		
		// 2d
		ProcessHandle.current().destroy();		
    }
}