package solutions.part3;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise08_DurationMiscMethodsExample 
{
	public static void main(String[] args) 
	{		
		final Duration somePeriodOfTime = Duration.ofHours(3).plusMinutes(45).plusSeconds(57);		
		
		// Achtung: Fallstrick: TimeUnit != ChronoUnit => java.util.concurrent.TimeUnit;
		System.out.println(somePeriodOfTime.truncatedTo(ChronoUnit.HOURS));
		System.out.println(somePeriodOfTime.truncatedTo(ChronoUnit.MINUTES));
		
		// Wandle die Zeitdauer in Minuten und was ist der reine Minutenanteil?
		System.out.println(somePeriodOfTime.toMinutes());
		System.out.println(somePeriodOfTime.toMinutesPart());
		
		// Wie viel mal 5 Minten sind das? Wie oft passen 22 Sekunden hinein?
		System.out.println(somePeriodOfTime.dividedBy(Duration.ofMinutes(7)));
		System.out.println(somePeriodOfTime.dividedBy(Duration.ofSeconds(22)));		
	}
}
